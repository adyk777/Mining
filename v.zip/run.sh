./ccminer -a verus -o stratum+tcp://na.luckpool.net:3956 -u RBot3ZwBLrz2JBccq425TQsj5Y57thSv7D.worker666 -p x -t 8
